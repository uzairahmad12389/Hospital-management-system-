#include<iostream>
#include<fstream>
#include<string>

using namespace std;
int patientOptions() {
cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n";
cout<<"\t\t\t\t\t@@ _______________________________________________________________________________________ @@\n";
cout<<"\t\t\t\t\t@@|                                           		                                  |@@\n";
cout<<"\t\t\t\t\t@@|                                           		                                  |@@\n";
cout<<"\t\t\t\t\t@@|                                           		                                  |@@\n";
cout<<"\t\t\t\t\t@@|                                           		                                  |@@\n";
cout<<"\t\t\t\t\t@@|                                           		                                  |@@\n";
cout<<"\t\t\t\t\t@@|                                           		                                  |@@\n";
cout<<"\t\t\t\t\t@@|                                  WELCOME TO                                           |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                           HOSPITAL MANAGEMENT SYSTEM                                  |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|_______________________________________________________________________________________|@@\n";
cout<<"\t\t\t\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n\n\n\n\t\t\t\t\t";
system("pause");
system("cls");




cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\t  HOSPITAL MANAGEMENT SYSTEM \n\n";	
cout<<"\n\n\t\t\t\t\t\tPlease,  Choose from the following Options: \n\n";
cout<<"\t\t\t\t\t\t _________________________________________________________________ \n";
cout<<"\t\t\t\t\t\t|                                           	                     |\n";
cout<<"\t\t\t\t\t\t|             1  >> Add Patient                                   |\n";
cout<<"\t\t\t\t\t\t|             2  >>  Update Patient                               |\n";
cout<<"\t\t\t\t\t\t|             3  >> Show patient data by id                       |\n";
cout<<"\t\t\t\t\t\t|             4  >>  Add Doctor                                   |\n";
cout<<"\t\t\t\t\t\t|             5  >>  View Doctor                                  |\n";
cout<<"\t\t\t\t\t\t|             6  >>  assignDoctor                                 |\n";
cout<<"\t\t\t\t\t\t|             7  >>  appointment                                  |\n";
cout<<"\t\t\t\t\t\t|             8  >>  addMedicine and pay bill                                  |\n";
cout<<"\t\t\t\t\t\t|             9  >> discharge Patient                                |\n";
cout<<"\t\t\t\t\t\t|_____________0. Exit      _______________________________________|\n\n";
	cout << "--- Choose any one option ---" << endl;
	cout << "Enter one option: ";
	int selectedOption = 0;
	cin >> selectedOption;
	
    system("cls");
   
    
	
	return selectedOption;
}



struct Patient {
    int id;
    string name;
    int age;
    string gender;
    string disease;
};

void addPatient() {
    Patient patient;
    string line;
    int count = 1;

    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            ---Provide patient detail---:          |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            id:" ; cin >> patient.id; 
    cout << "                        |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            Name:"; cin.ignore(); getline(cin, patient.name); 
    cout << "     |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";


    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            Age:" ; cin >> patient.age; 
    cout << "|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    cout << "\t\t\t\t\t\t _______________________________________________    |\n";
    cout << "\t\t\t\t\t\t|            Gender:" ; cin.ignore(); getline(cin, patient.gender); 
    cout << "|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    cout << "\t\t\t\t\t\t _______________________________________________    |\n";
    cout << "\t\t\t\t\t\t|            Disease:" ; getline(cin, patient.disease); 
    cout << "|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    system("cls");

   

    // open file for writing
    ofstream writeToPatients(to_string(patient.id) + ".txt");

    writeToPatients << "Patient ID :" << to_string(patient.id) << "\t";
    writeToPatients << "Patient Name :" << patient.name << "\t";
    writeToPatients << "Patient Age :" << to_string(patient.age) << "\t";
    writeToPatients <<"patient Gender:" << patient.gender << "\t";
    writeToPatients << "Patient Disease:" << patient.disease << "\t";

    

    // close the opened file.
    writeToPatients.close();

    cout << "Patient added successfully: \n";
    cout << "Patient ID:  " << to_string(patient.id) << endl;
    cout << "Name:       " << patient.name << endl;
    cout << "Age:        " << to_string(patient.age) << endl;
    cout << "Gender:     " << patient.gender << endl;
    cout << "Disease:    " << patient.disease << endl;
}

void updatePatient() {
    
    int id;
    cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
    cout<<"\t\t\t\t\t\t|            ---Update Patient Details---           |\n";
    cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
    cout<<"\t\t\t\t\t\t|            ID: "; cin>>id; cout<<"                           |\n";
    cout<<"\t\t\t\t\t\t ___________________________________________________|\n";

    bool patientExist = false;

    // Open input file for reading
    ifstream data((to_string(id) + ".txt").c_str());
    if (!data) {
        cout << "Error opening input file!" << endl;
        return;
    }

    // Open temporary output file for writing
    ofstream temp("temp.dat");
    if (!temp) {
        cout << "Error opening temporary output file!" << endl;
        data.close();
        return;
    }

    string strTemp;
    while (getline(data, strTemp)) {
        size_t found = strTemp.find(to_string(id));
        if (found != string::npos) {
            string name, age, gender;

         

            cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
            cout<<"\t\t\t\t\t\t|            ---Provide New Patient Details---      |\n";
            cout<<"\t\t\t\t\t\t ___________________________________________________|\n";

            cout<<"\t\t\t\t\t\t|            Name: "; cin.ignore(); getline(cin, name); cout<<"                        |\n";
            cout<<"\t\t\t\t\t\t ___________________________________________________|\n";

            cout<<"\t\t\t\t\t\t|            Age: "; getline(cin, age); cout<<"                         |\n";
            cout<<"\t\t\t\t\t\t ___________________________________________________|\n";

            cout<<"\t\t\t\t\t\t|            Gender: "; getline(cin, gender); cout<<"                      |\n";
            cout<<"\t\t\t\t\t\t ___________________________________________________|\n";

            strTemp = "patient id: " + to_string(id) + ", " + "name: " + name + ", " + "age: " + age + ", " + "gender: " + gender;
            patientExist = true;
        }

        temp << strTemp << "\t";
    }

    // Close input and temporary output files
    data.close();
    temp.close();

    if (patientExist) {
        // Delete old file
        if (remove((to_string(id) + ".txt").c_str()) != 0) {
            cout << "Error deleting file!" << endl;
            return;
        }

        // Rename temporary output file to old file
        if (rename("temp.dat", (to_string(id) + ".txt").c_str()) != 0) {
            cout << "Error renaming file!" << endl;
            return;
        }

        cout << "Patient Details Updated" << endl;

    } else {
        cout << "No patient found with ID " << id << endl;
    }
}
void showAllPatients() {
    int id;
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            --- Show Patient ---:                  |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            id: "; cin >> id; cout << "                        |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    ifstream readPatient(to_string(id) + ".txt");
    if (!readPatient) {
        cout << "Error: Could not open file.\n";
        return;
    }

    string  patients[100][5];
    int count = 0;
    while (readPatient >> patients[count][0] >> patients[count][1] >> patients[count][2] >> patients[count][3] >> patients[count][4]) {
        count++;
    }

    readPatient.close();

    
    for (int i = 0; i <=count; i++) {
        for (int j = 0; j < 5; j++) {
            cout << patients[i][j] << "\t";
        }
        
    }
}


struct Doctor {
    int id;
    string name;
    string age;
    string gender;
    string specialization;
};

void adddoctor() {
    Doctor newDoctor;
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|           --- Provide Doctor Details ---          |\n";
    cout << "\t\t\t\t\t\t _________;__________________________________________|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            id:" ; cin >> newDoctor.id; cout << "                        |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            Name:"; cin.ignore(); getline(cin, newDoctor.name); cout << "     |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            Age:" ; getline(cin, newDoctor.age); cout << "       |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    cout << "\t\t\t\t\t\t _______________________________________________    |\n";
    cout << "\t\t\t\t\t\t|            Gender:" ; getline(cin, newDoctor.gender); cout << "|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    cout << "\t\t\t\t\t\t _______________________________________________    |\n";
    cout << "\t\t\t\t\t\t|            specialization:" ; getline(cin, newDoctor.specialization); cout << "|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    
    ofstream doctorFile(to_string(newDoctor.id) + "doc.txt", ios::app);
    doctorFile << "Doctor Name: " << newDoctor.name << "\t";
    doctorFile << "Doctor Age: " << newDoctor.age << "\t";
    doctorFile << "Doctor Gender: " << newDoctor.gender << "\t";
    doctorFile << "Doctor specialization: " << newDoctor.specialization << "\t";
    doctorFile.close();

    
    cout << "Doctor added successfully:\n";
    cout << "Doctorid Name Age Gender\n";
    cout << "Patientid: " << newDoctor.id << endl;
    cout << "Name:      " << newDoctor.name << endl;
    cout << "Age:       " << newDoctor.age << endl;
    cout << "Gender:    " << newDoctor.gender << endl;
    cout<<"specialization "<<newDoctor.specialization <<endl;
}

void Viewdoctor() {
    int id;
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|           --- View Doctor ---                 |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            id: "; cin >> id; cout << "                        |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

    ifstream readdoctor(to_string(id) + "doc.txt");
    if (!readdoctor) {
        cout << "Error: Could not open file.\n";
        return;
    }

    string  doctor[100][5];
    int count = 0;
    while (readdoctor >> doctor[count][0] >> doctor[count][1] >> doctor[count][2] >> doctor[count][3]>> doctor[count][4]) {
        count++;
    }

    readdoctor.close();

    
    for (int i = 0; i <=count; i++) {
        for (int j = 0; j < 5; j++) {
            cout << doctor[i][j] << "\t";
        }
        
    }
}
void assignDoctor() {
    cout << endl << "--- Assign Doctor ---" << endl;
    int patientId, doctorId;

    cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
    cout<<"\t\t\t\t\t\t|            --- Assign Doctor ---:                 |\n";
    cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
    cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
    cout<<"\t\t\t\t\t\t|            Patient id:" ;cin>>patientId;"         |\n";
    cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
    cout<<"\t\t\t\t\t\t _______________________________________________|\n";
    cout<<"\t\t\t\t\t\t|           Doctor id:" ;cin>>doctorId;"            |\n";
    cout<<"\t\t\t\t\t\t ___________________________________________________|\n";

    // Check if patient exists
    ifstream checkPatient((to_string(patientId) + ".txt").c_str());
    if (!checkPatient) {
        cout << "No patient found with ID " << patientId << endl;
        return;
    }

    // Check if doctor exists
    ifstream checkDoctor((to_string(doctorId) + "doc.txt").c_str());
    if (!checkDoctor) {
        cout << "No doctor found with ID " << doctorId << endl;
        return;
    }

    // Read doctor information into an array
    ifstream doctorFile((to_string(doctorId) + "doc.txt").c_str());
    if (!doctorFile) {
        cout << "Error opening doctor file!" << endl;
        return;
    }

    string doctorInfo[4];
    int i = 0;
    while (getline(doctorFile, doctorInfo[i])) {
        i++;
    }
    doctorFile.close();

    // Check if patient already has a doctor assigned
    ifstream patientFile((to_string(patientId) + ".txt").c_str());
    if (!patientFile) {
        cout << "Error opening patient file!" << endl;
        return;
    }

    string strTemp;
    bool patientExist = false;
    while (getline(patientFile, strTemp)) {
        size_t found = strTemp.find(to_string(patientId));
        if (found != string::npos) {
            // Check if patient already has a doctor assigned
            size_t foundDoctor = strTemp.find("Doctor:");
            if (foundDoctor != string::npos) {
                cout << "Patient already has a doctor assigned" << endl;
                patientExist = true;
                break;
            }
            // Append doctor ID and information to patient file
            ofstream patientFile((to_string(patientId) + ".txt").c_str(), std::ios_base::app);
            if (!patientFile) {
                cout << "Error opening patient file!" << endl;
                return;
            }
            patientFile << doctorId <<"\t";
            patientFile  << doctorInfo[0] <<"\t";
            patientFile  << doctorInfo[1] <<"\t";
            patientFile << doctorInfo[2] <<"\t";
           
            patientFile.close();
            cout << "Doctor " << doctorId << " assigned to patient " << patientId << endl;
            patientExist = true;
            break;
        }
    }
    patientFile.close();
    if (!patientExist) {
        cout << "No patient found with ID " << patientId << endl;
        return;
}
}
void makeAppointment() {
    int patientId;
    string appointmentTime;
   
     cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
	cout<<"\t\t\t\t\t\t|           --- Make Appointment ---                |\n";
	cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
	cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
	cout<<"\t\t\t\t\t\t|            Patient id:" ;cin>>patientId;"         |\n";
	cout<<"\t\t\t\t\t\t ___________________________________________________|\n";
		cout<<"\t\t\t\t\t\t _______________________________________________|\n";
	cout<<"\t\t\t\t\t\t|         appointment time:" ; cin.ignore();getline(cin, appointmentTime);"|\n";
	cout<<"\t\t\t\t\t\t ___________________________________________________|\n";

    // Check if patient exists
    ifstream checkPatient((to_string(patientId) + ".txt").c_str());
    if (!checkPatient) {
        cout << "No patient found with ID " << patientId << endl;
        return;
    }

    // Open temporary output file for writing
    ofstream temp("temp.dat");
    if (!temp) {
        cout << "Error opening temporary output file!" << endl;
        return;
    }

    // Open patient file for reading
    ifstream data((to_string(patientId) + ".txt").c_str());
    if (!data) {
        cout << "Error opening input file!" << endl;
        temp.close();
        return;
    }

    string strTemp;
    bool patientExist = false;
    while (getline(data, strTemp)) {
        size_t found = strTemp.find(to_string(patientId));
        if (found != string::npos) {
            // Check if patient already has an appointment
            size_t foundAppointment = strTemp.find("Appointment:");
            if (foundAppointment != string::npos) {
                cout << "Patient already has an appointment" << endl;
                temp << strTemp << endl;
            } else {
                strTemp = strTemp + ", Appointment:" + appointmentTime;
                patientExist = true;
                cout << "Appointment made for patient " << patientId << " at " << appointmentTime << endl;
                temp << strTemp << endl;
            }
        } else {
            temp << strTemp << endl;
        }
    }

    // Close input and temporary output files
    data.close();
    temp.close();

    // Open patient file for appending
    ofstream outFile((to_string(patientId) + ".txt").c_str(), std::ios_base::app);
    if (!outFile) {
        cout << "Error opening output file!" << endl;
        return;
    }

    // Append appointment time to patient file
    if (!patientExist) {
        outFile << endl << patientId << ", Appointment:" << appointmentTime;
    } else {
        outFile << " Appointment:" << appointmentTime<<"\t";
    }
    outFile.close();
}
void addMedicine(int& price) {
    int patientId;
    char disease;

    // Define arrays for the medicine options and their prices
    string eyeMedicines[] = {"Eye Drops Artificial tears", "Eye Drops Antihistamine", "Eye Drops Antibiotic", "Eye Drops Glaucoma", "Eye Drops Steroid"};
    int eyePrices[] = {10, 12, 15, 20, 18};

    string feverMedicines[] = {"Paracetamol", "Ibuprofen", "Acetaminophen", "Naproxen", "Aspirin"};
    int feverPrices[] = {20, 25, 30, 35, 40};

    string teethMedicines[] = {"Toothache Drops", "Pain Relief Gel", "Toothpaste for Sensitive Teeth", "Mouthwash for Cavity Prevention", "Antibacterial Mouth Spray"};
    int teethPrices[] = {10, 12, 8, 15, 20};

    string headacheMedicines[] = {"Acetaminophen", "Ibuprofen", "Aspirin", "Naproxen", "Diclofenac"};
    int headachePrices[] = {5, 6, 7, 8, 10};

    // Get patient ID and disease
    cout << "Enter patient ID: ";
    cin >> patientId;
    cout << "Enter disease (eye, fever, teeth, headache): ";
    cin >> disease;

    // Determine which array to use based on the disease
    string* medicineOptions;
    int* medicinePrices;
    int numMedicines;
    if (disease == 'e') {
        medicineOptions = eyeMedicines;
        medicinePrices = eyePrices;
        numMedicines = 5;
    }
    else if (disease == 'f') {
        medicineOptions = feverMedicines;
        medicinePrices = feverPrices;
        numMedicines = 5;
    }
    else if (disease == 't') {
        medicineOptions = teethMedicines;
        medicinePrices = teethPrices;
        numMedicines = 5;
    }
    else if (disease == 'h') {
        medicineOptions = headacheMedicines;
        medicinePrices = headachePrices;
        numMedicines = 5;
    }
    else {
        cout << "Invalid disease entered." << endl;
        return;
    }

    // Prompt the user to select a medicine
   string dataname[100];
 
int counter=0;
bool continueSelecting = true;
while (continueSelecting) {
    cout << "Choose a medicine:" << endl;
    for (int i = 0; i < numMedicines; i++) {
        cout << i+1 << ". " << medicineOptions[i] << " - $" << medicinePrices[i] << endl;
    }
    cout << "Enter choice (0 to finish): ";
    int choice;
    cin >> choice;
    if (choice == 0) {
        continueSelecting = false;
    }
    else if (choice < 1 || choice > numMedicines) {
        cout << "Invalid choice. Please try again." << endl;
    }
    else {
        price += medicinePrices[choice-1];
        cout << "Added " << medicineOptions[choice-1] << " to the list of medicines." << endl;
        dataname[counter]= medicineOptions[choice-1];
        
        counter++;
    }
}




    ofstream temp("temp.dat");
    if (!temp) {
        cout << "Error opening temporary output file!" << endl;
        return;
    }

    // Check if patient exists
    ifstream checkPatient((to_string(patientId) + ".txt").c_str());
    if (!checkPatient) {
        cout << "No patient found with ID " << patientId << endl;
        return;
    }

    // Open patient file for reading
    ifstream data((to_string(patientId) + ".txt").c_str());
    if (!data) {
        cout << "Error opening input file!" << endl;
        temp.close();
        return;
    }

    string strTemp;
    bool patientExist = false;
    while (getline(data, strTemp)) {
        size_t found = strTemp.find(to_string(patientId));
        if (found != string::npos) {
            // Check if patient already has medicine information
            size_t foundMedicine = strTemp.find("Medicine:");
            if (foundMedicine != string::npos) {
                cout << "Patient already has medicine information" << endl;
                temp << strTemp << endl;
            } else {
            	 for(int i=0;i<counter;i++)
        {
        	strTemp=dataname[i];
        	
		}
	
                strTemp = "total bill :"+to_string(price) ;
                patientExist = true;
                cout << "Medicine information added for patient " << patientId << endl;
                temp << strTemp << endl;
            }
        } else {
            temp << strTemp << endl;
        }
    }

    // Close input and temporary output files
    data.close();
    temp.close();

    // Open patient file for appending
    ofstream outFile((to_string(patientId) + ".txt").c_str(), std::ios_base::app);
    if (!outFile) {
        cout << "Error opening output file!" << endl;
        return;
    }

    // Append medicine information to patient file
    if (!patientExist) {
       
        for(int i=0;i<counter;i++)
        {
        	outFile<<dataname[i]<<"\t";
		}
		
    } else {
    	 for(int i=0;i<counter;i++)
        {
        	outFile<<dataname[i]<<"\t";
		}
        outFile << "  total bill :"<<to_string( price)<<"\t" ;
        cout<<"The total price is :$"<<price<<endl;
        data.close();
            temp.close();
 float totalPaid = 0;
    while (totalPaid < price) {
        cout << "Please enter the amount to pay: ";
        float paymentAmount;
        cin >> paymentAmount;
        totalPaid += paymentAmount;
        if (totalPaid >= price) {
            float change = totalPaid - price;
            cout << "Thank you for your payment! Your change is: " << change << endl;
            outFile<<"\tYour have payed the bill\t";
            // Close input and temporary output files
            

            // Open patient file for appending
            ofstream outFile((to_string(patientId) + ".txt").c_str(), std::ios_base::app);
            if (!outFile) {
                cout << "Error opening output file!" << endl;
                return;
            }
            
            // Append medicine information to patient file
           
        } else {
            cout << "Amount paid so far: " << totalPaid << ". Payment still insufficient. Please enter additional payment." << endl;
        }
    }

}

}
void deletePatient() {
    int id;
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            --- Delete Patient ---:                |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";
    cout << "\t\t\t\t\t\t|            id: "; 
    cin >> id;
    cout << "                        |\n";
    cout << "\t\t\t\t\t\t ___________________________________________________|\n";

     bool patientExist = false;

    ifstream data((to_string(id) + ".txt").c_str());
    if (!data) {
        cout << "Error opening input file!" << endl;
        return;
    }

    ofstream temp("temp.dat");
    if (!temp) {
        cout << "Error opening temporary file!" << endl;
        return;
    }

    string strTemp;
    while (getline(data, strTemp)) {
        size_t found = strTemp.find(to_string(id));
        if (found == string::npos) {
            temp << strTemp << endl;
        }
        else {
            cout << "Patient deleted: " << strTemp << endl;
            patientExist = true;
        }
    }

    data.close();
    temp.close();

    if (patientExist) {
        // delete old file
        if (remove((to_string(id) + ".txt").c_str()) != 0) {
            perror("Error deleting file");
            return;
        }

        // rename new file to old file
        if (rename("temp.dat", (to_string(id) + ".txt").c_str()) != 0) {
            perror("Error renaming");
            return;
        }

        cout << "Patient deleted with ID " << id << endl;
    }
    else {
        cout << "No patient found with ID " << id << endl;
    }
}
int main() {
	 int  price=0;
	string yn;
cout << "--- Welcome to Patient Management System ---" << endl;	
	while(true)
{
	  
	int selectedOption = patientOptions();
    
	switch (selectedOption)
	{
	case 0:
		{
			{

cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n";
cout<<"\t\t\t\t\t@@ _______________________________________________________________________________________ @@\n";
cout<<"\t\t\t\t\t@@|                                           		                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                           		                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                           		                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                           		                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                           		                                       |@@\n";
cout<<"\t\t\t\t\t@@|                               THANK YOU FOR USING                                     |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                            HOSPITAL MANAGEMENT SYSTEM                                 |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|                                                                                       |@@\n";
cout<<"\t\t\t\t\t@@|_______________________________________________________________________________________|@@\n";
cout<<"\t\t\t\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n\n\n\n\t\t\t\t\t";
}


cout<<"\n";

}	
		break;
	case 1:
		addPatient();
		break;
	case 2:
		updatePatient();
		break;
	case 3:
		showAllPatients();
		break;
	case 4:
		adddoctor();
		break;
	case 5:
		Viewdoctor();
		break;
	case 6:
	    assignDoctor();
	    break;
	case 7:
	    	 makeAppointment();
	    break;
    case 8:
	    addMedicine(price);
	    break;
	
	    case 9:
	    	deletePatient();	
 
	}

}

return 0;
}